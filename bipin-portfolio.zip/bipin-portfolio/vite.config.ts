import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Static build for Vercel: output goes to /dist, assets are served from the site root.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    sourcemap: false,
    chunkSizeWarningLimit: 700,
  },
});
